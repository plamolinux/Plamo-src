/*
 * String to embed in binaries to identify package
 */

char pkg[]="$NetKit: netkit-rusers-0.17 $";
