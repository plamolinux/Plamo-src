/*
 * String to embed in binaries to identify package
 */

char pkg[]="$NetKit: bsd-finger-0.17 $";
