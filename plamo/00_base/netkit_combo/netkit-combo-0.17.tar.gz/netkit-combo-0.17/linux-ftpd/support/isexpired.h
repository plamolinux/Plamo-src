struct spwd;
int isexpired(const struct spwd *);
