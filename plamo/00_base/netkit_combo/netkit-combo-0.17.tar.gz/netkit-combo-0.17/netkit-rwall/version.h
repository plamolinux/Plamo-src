/*
 * String to embed in binaries to identify package
 */

char pkg[]="$NetKit: netkit-rwall-0.17 $";
