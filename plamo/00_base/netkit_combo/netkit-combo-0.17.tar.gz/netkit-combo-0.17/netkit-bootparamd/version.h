/*
 * String to embed in binaries to identify package
 */

char pkg[]="$NetKit: netkit-bootparamd-0.17 $";
