int logout(const char *line);
