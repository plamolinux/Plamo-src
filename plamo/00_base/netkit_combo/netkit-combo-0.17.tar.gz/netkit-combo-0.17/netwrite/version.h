/*
 * String to embed in binaries to identify package
 */

char pkg[]="$NetKit: netwrite-0.17 $";
