/* $Header: /p/tcsh/cvsroot/tcsh/patchlevel.h,v 3.185 2015/05/21 21:38:12 christos Exp $ */
/*
 * patchlevel.h: Our life story.
 */
#ifndef _h_patchlevel
#define _h_patchlevel

#define ORIGIN "Astron"
#define REV 6
#define VERS 19
#define PATCHLEVEL 0
#define DATE "2015-05-21"

#endif /* _h_patchlevel */
