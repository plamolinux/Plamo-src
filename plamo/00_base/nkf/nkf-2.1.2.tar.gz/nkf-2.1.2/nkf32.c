#include "nkf.c"
