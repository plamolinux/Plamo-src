#!/usr/bin/perl
#
#  $Id: cnvsysid.pl,v 1.2 2001/01/06 10:20:16 takamiti Exp $

die "can not open \"extipl.h\"\n" unless (open(F, "extipl.h"));
while(<F>) {
    chop;
    if (/^#define\s+(Boot_\S+)\s+(0x\d{2})/) {
	push(bootequ, "$1\t\tequ\t$2");
    }
}
close(F);

$cvsstr = '';
while (<>) {
    chop;
    $cvsstr = $_, next if ($cvsstr eq '' && /\s+\$Id:\s+/);
    next unless /^\s*\{/;
    next if /^\s*\/\*/;
    s/^\s*\{\s*//;
    s/\s*\}\s*//;
    s/,\s*/,/g;
    @a = split(',');
    $id = $a[0] =~ /^0x/ ? oct($a[0]) : $a[0];
    next if $id == 0;
    $sysname = $id == -1 ? 'sys_unknown' : sprintf("sys%02X_name", $id);
    if ($sysname eq 'sys_unknown') {
	push(sysidnt, "SysInd_tab_len\tequ\t\$ - SysInd_tab");
	push(sysidnt, "sysUnknown:\tdw\t0x0000, $sysname");
    } else {
	$x = "(($a[1])<<8)|$a[0]";
	push(sysidnt, "\t\tdw\t$x, $sysname");
    }
    push(sysname, "$sysname:\tdb\t$a[2],0");
}
if ($cvsstr ne '') {
    $cvsstr =~ s/^\s*\/\*\s*//;
    $cvsstr =~ s/\s*\*\/\s*$//;
    print ";;  $cvsstr\n\n";
}

{
    local($\, $,) = ("\n", "\n");
    print @bootequ;
}

print "\n\t\talign 2\n\n";
$x = shift(@sysidnt);
$x =~ s/^\t*//;
print "\t\t;;\t(flags << 8 | sysid), name_ptr\n"; 
print "SysInd_tab:\t$x\n";
print "sysind_tab_ln\tequ\t", '$ - SysInd_tab', "\n";
{
    local($\, $,) = ("\n", "\n");
    print @sysidnt;
    print "\n\t\t;; system name table";
    print @sysname;
}
