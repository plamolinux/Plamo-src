#!/bin/sh
#
# $Id: takevers.sh,v 1.1.1.1 2000/11/29 11:58:10 takamiti Exp $

set `grep VERSION extipl.h | sed -e 's/"//g'`
Vers=$3
set `grep DATE extipl.h | sed -e 's/"//g'`
Date=$3

Make=`date '+%Y/%m/%d %T'`
cat <<EOF
;;	version and date infomation
version1:	db	4
Information:	db	"extipl5/Gemini*castor",0
version2:	db	8, "Version: $Vers",0
;;version3:	db	8, "Release: $Date",0
;;version4:	db	8, "Make:    $Make",0
version5:	db	8, "Support: extipl@tsden.org",0
EOF
